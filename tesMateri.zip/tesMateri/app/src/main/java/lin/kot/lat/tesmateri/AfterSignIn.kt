package lin.kot.lat.tesmateri

import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.app.AppCompatActivity
import android.view.Gravity
import android.widget.TextView
import lin.kot.lat.tesmateri.R
import org.jetbrains.anko.*

class AfterSignIn : AppCompatActivity(), AnkoLogger {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AfterSignInView().setContentView(this)

        var username = intent.getStringExtra("username")
        var uname : TextView = findViewById(R.id.uname)

        uname.text = username

    }

    class AfterSignInView() : AnkoComponent<AfterSignIn> {
        @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
        override fun createView(ui: AnkoContext<AfterSignIn>) = with(ui) {
            verticalLayout {
                lparams {
                    width = matchParent
                    height = matchParent
                    verticalGravity = Gravity.CENTER
                }
                textView {
                    textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                    textSize = 35f
                    typeface = Typeface.DEFAULT_BOLD
                    text = "Selamat Datang,"
                }
                textView {
                    id = R.id.uname
                    textAlignment = TextView.TEXT_ALIGNMENT_CENTER
                    textSize = 30f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
                    text = "uname"
                }
            }
        }

    }
}