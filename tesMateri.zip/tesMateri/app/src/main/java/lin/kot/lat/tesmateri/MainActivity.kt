package lin.kot.lat.tesmateri

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.*

class MainActivity : AppCompatActivity(), AnkoLogger {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn.setOnClickListener {
            val uname = et_username.text.toString().trim()
            val passwd = et_password.text.toString().trim()
            HandleSignIn(uname, passwd)
        }
        tv_signin.setOnClickListener {
            startActivity(intentFor<SignUp>())
        }
    }

    //make a new method named HandleSignIn

    private fun HandleSignIn(uname: String, passwd: String){
        info { "Info Data Username : $uname, Info Data Password : $passwd" }
        when{
            uname.isEmpty() -> toast("Field Username Belum di isi")
            passwd.isEmpty() -> toast("Field Password Belum di isi")
        }
        if (uname.equals("fajar")&& passwd.equals("fajar")){
            startActivity(intentFor<AfterSignIn>("username" to uname))
            finish()
        }else {
            alert ( title = "Warning", message = "Username atau password salah"){
                positiveButton(buttonText = "Oke"){
                    //
                }
                isCancelable = false
            }.show()
        }
    }
}
