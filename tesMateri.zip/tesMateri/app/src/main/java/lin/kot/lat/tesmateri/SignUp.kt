package lin.kot.lat.tesmateri

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.sign_up.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.alert
import org.jetbrains.anko.info
import org.jetbrains.anko.toast

class SignUp : AppCompatActivity(), AnkoLogger{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sign_up)
        btn_signup.setOnClickListener {
            val fname = et_fullname.toString().trim()
            val uname = et_username.toString().trim()
            val passwd = et_password.toString().trim()
            HandleRegister(fname, uname, passwd)
        }
    }
    private fun HandleRegister(fname: String, uname: String, passwd: String) {
        info { "fullname: $fname \nusername: $uname \npassword: $passwd" }
        when {
            fname.isEmpty() -> toast("Fullname belum disisi")
            uname.isEmpty() -> toast("Username belum disisi")
            passwd.isEmpty() -> toast("Password belum disisi")
            else -> alert(title = "Register", message = "$uname berhasil di tambahkan") {
                positiveButton(buttonText = "OK") {
                    onBackPressed()
                    finish()
                }
                isCancelable = false
            }.show()
        }
    }
}